# Discord Nitro Generator & Checker

## Presentation 📖
**Discord Nitro Generator & Checker** is a simple, effective and fully configurable Discord Nitro generator.  
It supports advanced generation producing more than 100,000 links per minute

It will basically generate random codes and test them through Discord's API, and let you know where there's a hit.
The chances of a working link are once in a million. This gen does not promise you any nitro ;) Give it a try though

## Installation 💾

- Make sure Python is installed with modules
- python pip install requests
- python pip install aiohttp
- To run type `python main.py`(old version)/`python bettermain.py` (new version, for fast output)
- Select the number of links you want to generate

## Issues Faced By Users
People who try running this gen usually face problems like:
- File opens and then closes (Dont know how to run py files)
- Go watch a tutorial on youtube about how to run py files
- If you still face similar problems then run the code on replit (it is way easier on repl)

## Live Update - It Works In 2023
- It is working efficiently in 2023, Feel free to dm me if you face problems not mentioned above

## Support 🖐
In case of bug just add me **Alive#1100**
